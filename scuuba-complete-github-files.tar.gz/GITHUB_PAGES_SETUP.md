# SCUUBA GitHub Pages — complete file set

This folder contains ALL original SCUUBA files from the supplied project, plus the files needed for GitHub Pages.

Important:
- `index.html` is directly in the repository root.
- Original files were restored rather than removed.
- `.nojekyll` is included.
- `.github/workflows/pages.yml` provides an optional GitHub Pages Actions deployment.
- `api/site-control.js` is reserved for the later Python Control App and is not automatically loaded.

## Recommended GitHub setup

1. Create/open your `Scuuba` repository.
2. Upload everything inside this folder to the repository root.
3. Make sure `index.html` is visible directly on the first repository page.
4. Settings -> Pages.
5. If using the workflow, choose `GitHub Actions`.
   OR use `Deploy from a branch` with `main` and `/ (root)`.
6. Wait for the Pages deployment to finish.

Do not put Python admin passwords, tokens, or other secrets into GitHub.

GitHub Pages hosts the public frontend. The future Python Control App will communicate with a separately hosted Python API.
