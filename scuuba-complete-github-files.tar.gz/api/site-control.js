// Optional connection point for the future Python Control App.
// This file is not loaded automatically, so the existing SCUUBA design stays unchanged.
window.SCUUBAControl = {
  async getStatus(apiBase) {
    const url = apiBase.replace(/\/$/, "") + "/api/status";
    const response = await fetch(url, { cache: "no-store" });
    if (!response.ok) throw new Error("SCUUBA Control API unavailable");
    return response.json();
  }
};
